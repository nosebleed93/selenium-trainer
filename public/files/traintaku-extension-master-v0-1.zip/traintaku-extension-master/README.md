# traintaku-extension
Simple Chrome extension for grabbing image urls from websites
